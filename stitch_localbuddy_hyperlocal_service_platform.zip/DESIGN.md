---
name: Hyperlocal Utility System
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf4'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d4e4fc'
  on-surface: '#0d1c2e'
  on-surface-variant: '#424656'
  inverse-surface: '#223144'
  inverse-on-surface: '#eaf1ff'
  outline: '#727687'
  outline-variant: '#c2c6d8'
  surface-tint: '#0054d6'
  primary: '#0050cb'
  on-primary: '#ffffff'
  primary-container: '#0066ff'
  on-primary-container: '#f8f7ff'
  inverse-primary: '#b3c5ff'
  secondary: '#585e6c'
  on-secondary: '#ffffff'
  secondary-container: '#dde2f3'
  on-secondary-container: '#5e6473'
  tertiary: '#814e00'
  on-tertiary: '#ffffff'
  tertiary-container: '#a0650f'
  on-tertiary-container: '#fff7f2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae1ff'
  primary-fixed-dim: '#b3c5ff'
  on-primary-fixed: '#001849'
  on-primary-fixed-variant: '#003fa4'
  secondary-fixed: '#dde2f3'
  secondary-fixed-dim: '#c1c6d7'
  on-secondary-fixed: '#161c27'
  on-secondary-fixed-variant: '#414754'
  tertiary-fixed: '#ffddba'
  tertiary-fixed-dim: '#ffb866'
  on-tertiary-fixed: '#2b1700'
  on-tertiary-fixed-variant: '#673d00'
  background: '#f8f9ff'
  on-background: '#0d1c2e'
  surface-variant: '#d4e4fc'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  headline-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-otp:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  card-padding: 20px
  stack-gap: 12px
---

## Brand & Style

This design system is built on the pillars of **reliability, urgency, and approachability**. It serves a hyperlocal human assistance platform where speed of comprehension is vital. The visual language balances professional utility with a friendly, "buddy-like" persona.

The aesthetic follows a **Modern Corporate** style with leanings toward high-functionalism. It prioritizes clarity through generous whitespace, high-contrast ratios for outdoor legibility, and a card-based architecture that organizes complex logistical data into digestible units. Every element is designed to feel "active"—ready to respond to a user's immediate need for assistance.

## Colors

The color palette is engineered for high visibility and semantic clarity.
- **Action Blue (Primary):** Used for primary calls to action, active tracking paths, and interactive elements. It signifies movement and progress.
- **Grounding Navy (Secondary):** Used for primary headings and structural elements to provide a sense of stability and institutional trust.
- **Alert Accents:** Bright Yellow and Orange are reserved strictly for status changes, urgency indicators, and system notifications.
- **Neutral Scales:** A range of cool grays provides soft scaffolding for card backgrounds and secondary metadata without competing with functional "action" colors.

## Typography

This design system utilizes **Inter** for its exceptional legibility and neutral, systematic tone. 

- **Headlines:** Use tight letter-spacing and bold weights to create a sense of urgency and importance.
- **Body:** Standardized at 16px for primary information to ensure accessibility for users in high-glare outdoor environments.
- **OTP/Verification:** Uses a specialized high-tracking variant of the medium weight to ensure individual characters are distinct during rapid entry.
- **Labels:** Small-caps or heavy weights are used for status badges (e.g., ONLINE) to distinguish them from interactive text.

## Layout & Spacing

The layout philosophy is **Map-Centric**. The primary interface layer is a fluid map, with UI elements appearing as "floating" or "anchored" cards.

- **Grid:** A 12-column fluid grid for desktop and a 4-column grid for mobile.
- **Safe Zones:** High-priority buttons (e.g., "Request Buddy") are anchored to the bottom of the viewport within a dedicated safe-area container to ensure thumb-reachability.
- **Rhythm:** An 8px/4px baseline grid ensures vertical consistency across data-heavy lists and tracking stats.
- **Card-Based:** Content is encapsulated in white containers with defined margins to separate information from the map background.

## Elevation & Depth

To maintain the "Buddy" feel while ensuring components pop against complex map textures, the design system uses **Tonal Layers** combined with **Ambient Shadows**.

- **Level 0 (Map):** The base layer.
- **Level 1 (Sheet/Panel):** Fixed bottom sheets or sidebars use a very subtle 1px border (#E2E8F0) and a soft, wide-spread shadow (10% opacity) to lift them from the map.
- **Level 2 (Floating Cards/Buttons):** High-priority floating elements use a sharper shadow with 15% opacity to signify they are interactive and closer to the user.
- **Overlays:** Full-screen modals utilize a 40% opacity navy backdrop to pull focus entirely away from the map.

## Shapes

The design system uses a "Rounded" (0.5rem) corner logic to soften the technical nature of the platform.

- **Standard Elements:** Buttons and input fields use the base 8px (0.5rem) radius.
- **Large Containers:** Content cards and bottom sheets use the `rounded-xl` (1.5rem) radius at the top corners to create a friendly, modern "sheet" appearance.
- **Badges:** Use a full pill-shape (100px) to distinguish them from interactive buttons.

## Components

- **Buttons:**
    - **Primary:** Action Blue background, white text. Bold weight.
    - **Secondary:** Light gray background (#F1F5F9), navy text.
    - **Success/Danger:** Solid fills in green or red for critical actions (e.g., "End Mission," "Emergency Cancel").
- **OTP Inputs:** Single-digit boxes with 2px borders. Active state uses an Action Blue border. High-contrast focus state for outdoor use.
- **Status Badges:** 
    - **Online:** Green dot + "ONLINE" label in Label-MD typography. 
    - **Offline:** Neutral Gray dot + "OFFLINE".
- **Tracking Cards:** Use a horizontal layout for "Buddy Details" (Avatar on left, Name/Rating in center, Contact Action on right).
- **Map Markers:** Teardrop shapes using the Primary color with white iconography in the center for high visibility.